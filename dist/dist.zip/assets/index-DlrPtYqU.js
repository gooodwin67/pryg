const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./main-B7d6DNTb.js","./three-DOpQIdiv.js"])))=>i.map(i=>d[i]);
let E;
let __tla = (async ()=>{
    (function() {
        const i = document.createElement("link").relList;
        if (i && i.supports && i.supports("modulepreload")) return;
        for (const e of document.querySelectorAll('link[rel="modulepreload"]'))a(e);
        new MutationObserver((e)=>{
            for (const t of e)if (t.type === "childList") for (const r of t.addedNodes)r.tagName === "LINK" && r.rel === "modulepreload" && a(r);
        }).observe(document, {
            childList: !0,
            subtree: !0
        });
        function l(e) {
            const t = {};
            return e.integrity && (t.integrity = e.integrity), e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy), e.crossOrigin === "use-credentials" ? t.credentials = "include" : e.crossOrigin === "anonymous" ? t.credentials = "omit" : t.credentials = "same-origin", t;
        }
        function a(e) {
            if (e.ep) return;
            e.ep = !0;
            const t = l(e);
            fetch(e.href, t);
        }
    })();
    let v, g, p;
    v = "modulepreload";
    g = function(m, i) {
        return new URL(m, i).href;
    };
    p = {};
    E = function(i, l, a) {
        let e = Promise.resolve();
        if (l && l.length > 0) {
            let y = function(n) {
                return Promise.all(n.map((c)=>Promise.resolve(c).then((u)=>({
                            status: "fulfilled",
                            value: u
                        }), (u)=>({
                            status: "rejected",
                            reason: u
                        }))));
            };
            const r = document.getElementsByTagName("link"), o = document.querySelector("meta[property=csp-nonce]"), h = o?.nonce || o?.getAttribute("nonce");
            e = y(l.map((n)=>{
                if (n = g(n, a), n in p) return;
                p[n] = !0;
                const c = n.endsWith(".css"), u = c ? '[rel="stylesheet"]' : "";
                if (!!a) for(let f = r.length - 1; f >= 0; f--){
                    const d = r[f];
                    if (d.href === n && (!c || d.rel === "stylesheet")) return;
                }
                else if (document.querySelector(`link[href="${n}"]${u}`)) return;
                const s = document.createElement("link");
                if (s.rel = c ? "stylesheet" : v, c || (s.as = "script"), s.crossOrigin = "", s.href = n, h && s.setAttribute("nonce", h), document.head.appendChild(s), c) return new Promise((f, d)=>{
                    s.addEventListener("load", f), s.addEventListener("error", ()=>d(new Error(`Unable to preload CSS for ${n}`)));
                });
            }));
        }
        function t(r) {
            const o = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (o.payload = r, window.dispatchEvent(o), !o.defaultPrevented) throw r;
        }
        return e.then((r)=>{
            for (const o of r || [])o.status === "rejected" && t(o.reason);
            return i().catch(t);
        });
    };
    window.__loadMain = ()=>E(()=>import("./main-B7d6DNTb.js").then(async (m)=>{
                await m.__tla;
                return m;
            }), __vite__mapDeps([0,1]), import.meta.url);
})();
export { E as _, __tla };
